from . import hello_python

if __name__ == "__main__":
    hello_python()
