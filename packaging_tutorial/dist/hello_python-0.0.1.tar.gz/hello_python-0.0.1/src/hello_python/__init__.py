def hello_python():
    print("Hello Python!")
